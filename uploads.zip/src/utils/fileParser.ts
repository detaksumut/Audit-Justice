export async function extractTextFromFile(file: File): Promise<string> {
  if (file.type === "text/plain" || file.name.endsWith(".txt")) {
    return await file.text();
  }
  
  if (file.type === "application/pdf" || file.name.endsWith(".pdf")) {
    const formData = new FormData();
    formData.append("file", file);
    
    const response = await fetch('/api/parse-pdf', {
      method: 'POST',
      body: formData,
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Gagal memproses file PDF");
    }
    
    const data = await response.json();
    return data.text;
  }
  
  throw new Error("Format tidak didukung. Harap unggah dokumen PDF atau Teks murni (.txt).");
}
