"use client";

import { useState } from "react";
import UploadDropzone from "@/components/UploadDropzone";
import MarkdownReport from "@/components/MarkdownReport";
import { saveArchive } from "@/utils/archive";

export default function AgamaPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [markdownData, setMarkdownData] = useState<string | null>(null);
  const [rawText, setRawText] = useState<string | null>(null);
  const [isMockResult, setIsMockResult] = useState<boolean>(false);
  const [currentFileName, setCurrentFileName] = useState<string>("");

  const handleUploadSuccess = async (file: File) => {
    setIsLoading(true);
    setCurrentFileName(file.name);
    
    try {
      const { extractTextFromFile } = await import("@/utils/fileParser");
      const textToAnalyze = await extractTextFromFile(file);
      setRawText(textToAnalyze);

      const localApiKey = localStorage.getItem("gemini_api_key");

      // Panggil API Backend Gemini
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToAnalyze, type: "agama", apiKey: localApiKey })
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Gagal menghubungi server AI.");
      }

      setMarkdownData(result.data);
      setIsMockResult(result.isMock === true);
      
      // Simpan ke Arsip Lokal
      saveArchive(file.name, "Hukum Agama", result.data);
      
    } catch (err: any) {
      alert("Error: " + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 md:p-8 lg:p-12 max-w-7xl mx-auto">
      <div className="mb-8 border-b border-[var(--color-border-main)] pb-6">
        <h1 className="text-4xl font-serif font-bold text-[var(--color-primary)] mb-3 tracking-tight">Audit Keputusan Pengadilan Agama</h1>
        <p className="text-[var(--color-text-muted)] text-lg">Platform Audit Komprehensif berbasis Al-Qur'an, Hadis, dan Kompilasi Hukum Islam (KHI).</p>
      </div>

      
      <div className={!markdownData ? "block mt-12" : "hidden"}>
        
          <UploadDropzone onUploadSuccess={handleUploadSuccess} isLoading={isLoading} />
        
      </div>

      <div className={markdownData ? "block" : "hidden"}>
        {markdownData && <MarkdownReport rawText={rawText || undefined} isMock={isMockResult} content={markdownData} fileName={currentFileName} onReset={() => { setMarkdownData(null); setIsMockResult(false); setRawText(null); }} />}
      </div>
                
    </div>
  );
}
