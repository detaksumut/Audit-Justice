"use client";

import { useState } from "react";
import UploadDropzone from "@/components/UploadDropzone";
import MarkdownReport from "@/components/MarkdownReport";
import { saveArchive } from "@/utils/archive";
import { ShieldAlert } from "lucide-react";

export default function KepolisianPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [markdownData, setMarkdownData] = useState<string | null>(null);
  const [rawText, setRawText] = useState<string | null>(null);
  const [isMockResult, setIsMockResult] = useState<boolean>(false);
  const [currentFileName, setCurrentFileName] = useState<string>("");

  const handleUploadSuccess = async (file: File) => {
    setIsLoading(true);
    setCurrentFileName(file.name);
    
    try {
      const { extractTextFromFile } = await import("@/utils/fileParser");
      const textToAnalyze = await extractTextFromFile(file);
      setRawText(textToAnalyze);

      const localApiKey = localStorage.getItem("gemini_api_key");

      // Panggil API Backend Gemini
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToAnalyze, type: "kepolisian", apiKey: localApiKey })
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Gagal menghubungi server AI.");
      }

      setMarkdownData(result.data);
      setIsMockResult(result.isMock === true);
      saveArchive(file.name, "Audit Kepolisian", result.data);
    } catch (err: any) {
      alert("Error: " + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 md:p-8 lg:p-12 max-w-7xl mx-auto">
      <div className="mb-12 border-b border-[var(--color-border-main)] pb-6 flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[var(--color-primary)] mb-2 tracking-tight">Audit BAP Kepolisian</h1>
          <p className="text-[var(--color-text-muted)] text-lg">Platform Audit Berita Acara Pemeriksaan (BAP) dan Proses Penyelidikan.</p>
        </div>
        <ShieldAlert className="w-16 h-16 text-[var(--color-primary)] opacity-80" />
      </div>

      
      <div className={!markdownData ? "block mt-12" : "hidden"}>
        <UploadDropzone onUploadSuccess={handleUploadSuccess} isLoading={isLoading} />
      </div>

      <div className={markdownData ? "block" : "hidden"}>
        {markdownData && <MarkdownReport rawText={rawText || undefined} isMock={isMockResult} content={markdownData} fileName={currentFileName} onReset={() => { setMarkdownData(null); setIsMockResult(false); setRawText(null); }} />}
      </div>
                
    </div>
  );
}
