"use client";

import { useState, useEffect } from "react";
import { getArchives, deleteArchive, ArchiveItem } from "@/utils/archive";
import MarkdownReport from "@/components/MarkdownReport";
import { FileText, Trash2, Clock, Scale } from "lucide-react";

export default function ArsipPage() {
  const [archives, setArchives] = useState<ArchiveItem[]>([]);
  const [selectedArchive, setSelectedArchive] = useState<ArchiveItem | null>(null);

  useEffect(() => {
    // Load archives on mount
    setArchives(getArchives());
  }, []);

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    // Dihapus sementara window.confirm karena Simulator HP memblokirnya
    deleteArchive(id);
    setArchives(getArchives());
    if (selectedArchive?.id === id) {
      setSelectedArchive(null);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString('id-ID', {
      dateStyle: 'medium',
      timeStyle: 'short'
    });
  };

  return (
    <>
      <div className={selectedArchive ? "block p-4 md:p-8 lg:p-12 max-w-7xl mx-auto" : "hidden"}>
        {selectedArchive && (
          <MarkdownReport 
            content={selectedArchive.content} 
            fileName={selectedArchive.fileName} 
            onReset={() => setSelectedArchive(null)} 
          />
        )}
      </div>

      <div className={!selectedArchive ? "block p-4 md:p-8 lg:p-12 max-w-7xl mx-auto" : "hidden"}>
        <div className="mb-12 border-b border-[var(--color-border-main)] pb-6 flex items-end justify-between">
          <div>
            <h1 className="text-4xl font-serif font-bold text-[var(--color-primary)] mb-2 tracking-tight">Arsip Laporan</h1>
            <p className="text-[var(--color-text-muted)] text-lg">Semua hasil audit dan draf litigasi yang tersimpan secara lokal di browser Anda.</p>
          </div>
        </div>

        {archives.length === 0 ? (
          <div className="border border-[var(--color-border-main)] p-16 text-center flex flex-col items-center justify-center bg-[var(--color-bg-sidebar)]">
            <Scale className="w-16 h-16 text-[var(--color-border-main)] mb-6" />
            <p className="text-2xl font-serif font-bold text-[var(--color-text-main)] mb-2">Belum Ada Dokumen</p>
            <p className="text-md text-[var(--color-text-muted)]">Anda belum pernah melakukan analisis dokumen hukum apapun. Hasil analisis akan otomatis tersimpan di sini.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {archives.map((item) => (
              <div 
                key={item.id} 
                onClick={() => setSelectedArchive(item)}
                className="glass-panel p-6 cursor-pointer hover:-translate-y-1 transition-transform border-t-4 border-t-[var(--color-primary)] group"
              >
                <div className="flex justify-between items-start mb-4">
                  <span className="px-3 py-1 bg-[var(--color-primary)]/10 text-[var(--color-primary)] text-xs font-bold uppercase tracking-wider rounded">
                    {item.category}
                  </span>
                  <button 
                    onClick={(e) => handleDelete(e, item.id)}
                    className="text-[var(--color-text-muted)] hover:text-red-500 transition-colors"
                    title="Hapus Arsip"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex items-start gap-3 mb-4">
                  <FileText className="w-6 h-6 text-[var(--color-text-main)] shrink-0 mt-1 group-hover:text-[var(--color-primary)] transition-colors" />
                  <h3 className="font-serif font-bold text-[var(--color-text-main)] text-lg line-clamp-2" title={item.fileName}>
                    {item.fileName}
                  </h3>
                </div>
                
                <div className="flex items-center gap-2 text-xs text-[var(--color-text-muted)] mt-auto pt-4 border-t border-[var(--color-border-main)]">
                  <Clock className="w-3 h-3" />
                  {formatDate(item.timestamp)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
