"use client";

import React, { useState } from 'react';

export default function AuditPage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulasi proses AI (di masa depan ini akan memanggil API Gemini)
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
    }, 3000);
  };

  if (success) {
    return (
      <div className="animate-fade-in container" style={{ maxWidth: '800px' }}>
        <div className="card" style={{ textAlign: 'center', padding: '4rem 2rem' }}>
          <div style={{ 
            width: '80px', height: '80px', borderRadius: '50%', backgroundColor: 'var(--success)', 
            color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', 
            fontSize: '2rem', margin: '0 auto 1.5rem auto' 
          }}>
            ✓
          </div>
          <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Audit Selesai!</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>
            Sistem telah selesai mengaudit putusan perkara Anda berdasarkan Logika Hukum, Filosofi, dan Norma.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
            <a href="/" className="btn" style={{ border: '1px solid var(--border-color)', backgroundColor: 'transparent' }}>
              Kembali ke Dashboard
            </a>
            <a href="/audit/report" className="btn btn-gold">Lihat Laporan Audit</a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in container" style={{ maxWidth: '800px' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>Audit Perkara Baru</h2>
        <p style={{ color: 'var(--text-secondary)' }}>
          Masukkan detail perkara dan putusan pengadilan yang ingin Anda audit. Sistem akan menganalisis objektivitas dan keadilan putusan ini.
        </p>
      </div>

      <div className="card glass">
        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginBottom: '1.5rem' }}>
            <div className="input-group" style={{ marginBottom: 0 }}>
              <label className="input-label">Nomor Perkara</label>
              <input type="text" className="input-field" placeholder="Contoh: 145/Pid.B/2026/PN.Jkt" required />
            </div>
            <div className="input-group" style={{ marginBottom: 0 }}>
              <label className="input-label">Jenis Perkara</label>
              <select className="input-field" required>
                <option value="">Pilih Jenis...</option>
                <option value="pidana">Pidana</option>
                <option value="perdata">Perdata</option>
                <option value="tipikor">Tindak Pidana Korupsi</option>
              </select>
            </div>
          </div>

          <div className="input-group">
            <label className="input-label">Tingkat Pengadilan</label>
            <select className="input-field" required>
              <option value="pn">Pengadilan Negeri (Tingkat Pertama)</option>
              <option value="pt">Pengadilan Tinggi (Banding)</option>
              <option value="ma">Mahkamah Agung (Kasasi / PK)</option>
            </select>
          </div>

          <div className="input-group">
            <label className="input-label">Dakwaan / Gugatan Utama (Ringkasan)</label>
            <textarea className="input-field" rows={3} placeholder="Jelaskan secara singkat apa dakwaan atau gugatannya..." required></textarea>
          </div>

          <div className="input-group">
            <label className="input-label">Teks Putusan Lengkap (Pertimbangan Hukum Hakim)</label>
            <textarea className="input-field" rows={10} placeholder="Tempelkan (paste) teks putusan pengadilan atau pertimbangan hukum (ratio decidendi) di sini..." required></textarea>
          </div>

          <div style={{ marginTop: '2.5rem', display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
            <a href="/" className="btn" style={{ border: '1px solid var(--border-color)', backgroundColor: 'transparent' }}>
              Batal
            </a>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Menganalisis... (AI Bekerja)' : 'Mulai Audit AI'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
