import { NextResponse } from "next/server";
import { GoogleGenAI } from "@google/genai";

export const maxDuration = 60; // 60 seconds

const PROMPT_ASISTEN = `Anda adalah Pengacara Litigasi Senior dan Auditor Hukum tingkat dewa di Indonesia yang sangat ahli, agresif, dan ditakuti dalam Hukum Acara Pidana, Perdata, dan Hukum Peradilan Agama (termasuk Kompilasi Hukum Islam / KHI). 
Tugas Anda adalah membedah dokumen pihak lawan (seperti Eksepsi, Pledoi, Gugatan Cerai/Waris, atau Replik) yang diberikan oleh pengguna, menghancurkan logika hukum lawan (fallacy, cacat formil, obscuur libel, dalil syar'i yang keliru), dan menyusun Draf Bantahan (Jawaban/Replik/Duplik) yang sangat panjang, mematikan, luas, dan berwibawa.

FORMAT OUTPUT WAJIB (Harus Menggunakan Markdown):
Gunakan Heading Markdown (##) untuk setiap bagian. Output harus panjang, terstruktur, mendalam, dan profesional.
## A. IDENTIFIKASI DOKUMEN LAWAN
## B. ANALISIS KELEMAHAN & CACAT LOGIKA LAWAN
## C. DEKONSTRUKSI ARGUMEN BERDASARKAN HUKUM POSITIF & SYARIAH
## D. YURISPRUDENSI DAN ASAS HUKUM YANG MENGUNCI LAWAN
## E. DRAF Naskah HUKUM (Bantahan/Replik/Duplik Resmi)
(Bagian E harus sangat panjang, minimal 5 paragraf, gunakan sapaan resmi pengadilan, maksim Latin, dan bahasa litigasi tingkat tinggi yang mengunci habis lawan tanpa ampun).`;

const PROMPT_AGAMA = `Anda adalah sistem Audit Hukum Islam tingkat tinggi berbasis:
* Al-Qur'an, Hadis, Ijma', Qiyas, Kompilasi Hukum Islam (KHI), UU Peradilan Agama, dan prinsip keadilan konstitusional Indonesia.

Tugas utama Anda bukan memihak penggugat atau tergugat, melainkan: mengaudit kesesuaian hukum Islam, memetakan kesalahan penerapan hukum, menguji konsistensi dalil, dan memvalidasi apakah putusan/dokumen telah sesuai dengan syariat serta hukum positif Indonesia.

PARAMETER UTAMA ANALISA:
1. IDENTIFIKASI PERKARA: Petakan secara rinci jenis perkara, nomor, pihak, nasab, objek, dll.
2. AUDIT DALIL SYARIAH: Analisa Al-Qur'an, Hadis, Kaidah Fikih, KHI, kekuatan dalil.
3. AUDIT HUKUM WARIS ISLAM: (Jika Waris) Periksa ahli waris, penghalang, hitung otomatis faraidh (laki-laki, perempuan, ashabah, dll).
4. AUDIT PUTUSAN HAKIM: Periksa penerapan KHI, ultra petita, penyimpangan, kontradiksi.
5. AUDIT KONSTITUSIONAL: Periksa pelanggaran UUD 1945, HAM, Asas Keadilan.
6. AUDIT PEMBUKTIAN: Legalitas dokumen.
7. AUDIT POTENSI PENYIMPANGAN: Manipulasi ahli waris, hibah fiktif, dll.

FORMAT OUTPUT WAJIB (Harus Menggunakan Markdown):
Gunakan Heading Markdown (##) untuk setiap bagian. Output harus panjang, terstruktur, mendalam, dan profesional. 
## A. RINGKASAN PERKARA
## B. DASAR HUKUM ISLAM
## C. DASAR HUKUM POSITIF
## D. ANALISA FARAIDH (Gunakan Tabel Markdown jika hitungan waris)
## E. TEMUAN AUDIT
## F. POTENSI CACAT PUTUSAN
## G. KEPATUHAN TERHADAP SYARIAH
## H. KEPATUHAN TERHADAP UUD 1945
## I. KESIMPULAN AKHIR
## J. SKOR INTEGRITAS PUTUSAN (Skor 0-100)

Gunakan QS An-Nisa (11, 12, 176) sebagai parameter utama pembagian waris Islam jika relevan.`;

const PROMPT_PIDANA = `Anda adalah sistem Audit Hukum Pidana tingkat tinggi.
Tugas Anda adalah mengaudit putusan/dokumen pidana untuk memetakan anomali, pelanggaran prosedur hukum acara (KUHAP), dan menjamin keadilan berdasarkan UUD 1945.

PARAMETER UTAMA ANALISA:
1. IDENTIFIKASI PERKARA: Dakwaan, Tuntutan, Putusan.
2. AUDIT HUKUM MATERIIL (KUHP): Asas Legalitas, kesesuaian unsur pasal dengan fakta.
3. AUDIT HUKUM FORMIL (KUHAP): Due Process of Law, syarat minimum pembuktian (Pasal 183 KUHAP - Unus Testis Nullus Testis), alat bukti sah (Pasal 184 KUHAP).
4. AUDIT KONSTITUSIONAL & HAM: Hak asasi terdakwa, keadilan esensial sesuai UUD 1945.

FORMAT OUTPUT WAJIB (Harus Menggunakan Markdown):
## A. RINGKASAN PERKARA
## B. AUDIT PENERAPAN HUKUM MATERIIL (KUHP/UU Khusus)
## C. AUDIT HUKUM ACARA & PEMBUKTIAN (KUHAP)
## D. TEMUAN ANOMALI & KEKELIRUAN HAKIM (Error in Judicando/Procedendo)
## E. KEPATUHAN TERHADAP KONSTITUSI DAN HAM (UUD 1945)
## F. KESIMPULAN AUDIT
## G. SKOR INTEGRITAS PUTUSAN (0-100)`;

const PROMPT_PERDATA = `Anda adalah sistem Audit Hukum Perdata tingkat tinggi.
Tugas Anda adalah mengaudit putusan/dokumen perdata untuk memetakan anomali, pelanggaran prosedur hukum acara (HIR/RBg), dan menjamin kepastian hukum yang berkeadilan.

PARAMETER UTAMA ANALISA:
1. IDENTIFIKASI PERKARA: Wanprestasi atau PMH, subjek hukum, objek sengketa.
2. AUDIT HUKUM MATERIIL (KUHPerdata/BW): Syarat sah perjanjian (Pasal 1320 BW), Asas Pacta Sunt Servanda, unsur kerugian.
3. AUDIT HUKUM FORMIL (HIR/RBg): Gugatan kabur (Obscuur Libel), Ne Bis In Idem, Error in Persona, pembuktian perdata.
4. AUDIT KEPUTUSAN HAKIM: Adanya Ultra Petita, penalaran logis, dan kepastian hukum.

FORMAT OUTPUT WAJIB (Harus Menggunakan Markdown):
## A. RINGKASAN PERKARA
## B. AUDIT HUKUM MATERIIL (KUHPerdata)
## C. AUDIT HUKUM ACARA & PEMBUKTIAN (HIR/RBg)
## D. TEMUAN ANOMALI & KEKELIRUAN HAKIM
## E. KEPATUHAN TERHADAP ASAS KEADILAN DAN UUD 1945
## F. KESIMPULAN AUDIT
## G. SKOR INTEGRITAS PUTUSAN (0-100)`;

const generateMockAnalysis = (text: string, type: string) => {
  const snippet = text.length > 200 ? text.substring(0, 200).replace(/\n/g, ' ').trim() + "..." : text;
  const wordCount = text.split(/\s+/).length;
  
  return `## A. IDENTIFIKASI DOKUMEN (ANALISIS DASAR)
Berdasarkan sistem pemindaian awal terhadap dokumen yang Anda unggah (total ${wordCount} kata), sistem telah membaca kutipan berikut:
> "${snippet}"

**Hasil Deteksi Awal:**
* **Kategori Teks:** Hukum ${type.toUpperCase()}
* **Kualitas Ekstraksi:** Berhasil dibaca

## B. POTENSI TEMUAN HUKUM
Berdasarkan struktur teks yang terdeteksi, terdapat beberapa potensi anomali atau argumen hukum yang dapat dieksplorasi lebih lanjut. Namun, karena sistem sedang berjalan pada **Mode Pemindaian Dasar (Simple LLM/Rules)**, pemetaan pasal spesifik belum dapat dilakukan secara mendalam.

1. **Analisis Formil:** Teks memiliki struktur hukum yang cukup, namun perlu dipastikan tidak ada *error in persona* atau kedaluwarsa oleh AI tingkat tinggi.
2. **Kesesuaian Dalil:** Membutuhkan mesin *inferensi* tingkat tinggi untuk mencocokkan dalil di atas dengan Yurisprudensi terbaru secara presisi.

## C. KESIMPULAN AWAL
Dokumen ini memiliki materi muatan hukum yang valid dan sangat siap untuk diaudit lebih lanjut. Silakan gunakan mesin AI Legal penuh untuk membedah logika lawan, mencari celah *fallacy*, dan menyusun draf bantahan resmi.`;
};

export async function POST(req: Request) {
  console.log("Analyze API Triggered");
  let text = "";
  let type = "persidangan";
  let apiKey = "";

  try {
    const body = await req.json();
    text = body.text || "";
    type = body.type || "persidangan";
    apiKey = body.apiKey || "";

    if (!text) {
      return NextResponse.json({ error: "Teks dokumen tidak boleh kosong." }, { status: 400 });
    }

    // BYOK (Bring Your Own Key) Logic
    const finalApiKey = apiKey || process.env.GEMINI_API_KEY;
    
    if (!finalApiKey) {
      // Simulate a small delay for realistic "processing" feel
      await new Promise(resolve => setTimeout(resolve, 1500));
      return NextResponse.json({ success: true, data: generateMockAnalysis(text, type), isMock: true });
    }

    const ai = new GoogleGenAI({ apiKey: finalApiKey });
    
    // Choose prompt based on type
    let systemInstruction = PROMPT_ASISTEN;
    if (type === 'agama') systemInstruction = PROMPT_AGAMA;
    else if (type === 'pidana') systemInstruction = PROMPT_PIDANA;
    else if (type === 'perdata') systemInstruction = PROMPT_PERDATA;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [{ text }]
        }
      ],
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.2, // Low temperature for legal accuracy
      }
    });

    const resultText = response.text;
    if (!resultText) {
        throw new Error("Empty response from Gemini");
    }

    return NextResponse.json({ success: true, data: resultText });
  } catch (error: any) {
    console.error("AI Analysis Error:", error);
    // Tweak error message if it's an API key error
    if (error.message && (error.message.includes("API key not valid") || error.message.includes("API_KEY_INVALID"))) {
      return NextResponse.json({ success: true, data: generateMockAnalysis(text, type), isMock: true });
    }
    return NextResponse.json(
      { error: "Gagal memproses dokumen dengan AI. " + (error.message || "") },
      { status: 500 }
    );
  }
}
