import { NextResponse } from 'next/server';
import { generateLicenseKey } from '@/utils/crypto';

export async function POST(req: Request) {
  try {
    const { hwid } = await req.json();

    if (!hwid) {
      return NextResponse.json({ error: "HWID tidak boleh kosong." }, { status: 400 });
    }

    const licenseKey = generateLicenseKey(hwid);

    return NextResponse.json({ licenseKey });
  } catch (error) {
    return NextResponse.json({ error: "Terjadi kesalahan internal." }, { status: 500 });
  }
}
