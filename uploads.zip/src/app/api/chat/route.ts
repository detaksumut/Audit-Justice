import { NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

export const maxDuration = 60; // Set max duration for API route (60 seconds)

export async function POST(req: Request) {
  try {
    const { messages, documentText, userApiKey } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: 'Messages array is required' },
        { status: 400 }
      );
    }

    if (!documentText) {
      return NextResponse.json(
        { error: 'Document text is required to provide context' },
        { status: 400 }
      );
    }

    const hasCustomKey = !!userApiKey;
    const apiKey = hasCustomKey ? userApiKey : process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key is missing. Please set GEMINI_API_KEY in .env.local or provide a custom key.' },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({ apiKey });

    // System instruction varies based on whether it's a free or premium user
    let systemInstruction = `Anda adalah asisten hukum AI ahli ("Audit Justice"). 
Tugas Anda adalah menjawab pertanyaan pengguna berdasarkan dokumen hukum berikut.
Jangan menjawab pertanyaan di luar konteks dokumen ini.

--- TEKS DOKUMEN ---
${documentText.substring(0, 30000)} // Limit document text to save tokens
--------------------
`;

    if (!hasCustomKey) {
      systemInstruction += `\nPERINGATAN PENTING: Pengguna ini menggunakan mode GRATIS (Tanpa API Key pribadi). 
Aturan Ketat untuk Anda:
1. Jawablah dengan SANGAT SINGKAT, maksimal 2-3 kalimat saja.
2. Jangan memberikan analisis mendalam.
3. Di akhir setiap jawaban, WAJIB tambahkan kalimat ini persis seperti ini: "(Untuk memaksimalkan aplikasi ini silakan gunakan API KEY Anda sendiri di menu pengaturan)".`;
    } else {
      systemInstruction += `\nPengguna ini menggunakan mode PREMIUM (API Key pribadi). Jawablah selengkap, semendetail, dan seprofesional mungkin. Berikan kutipan pasal atau halaman jika ada.`;
    }

    // Format messages for Google Gen AI chat
    // Google GenAI expects a history of previous messages and the new message
    // messages: [{role: 'user' | 'model', content: '...'}]
    
    // We can just use generateContent with the full conversation history prepended, 
    // or use the chat session. Let's build a structured prompt.
    let fullPrompt = systemInstruction + "\n\nRiwayat Percakapan:\n";
    for (const msg of messages) {
      fullPrompt += `${msg.role === 'user' ? 'User' : 'AI'}: ${msg.content}\n`;
    }
    
    // The last message is the current question, so the prompt ends with the AI's turn
    fullPrompt += "AI: ";

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: fullPrompt,
      config: {
        temperature: 0.2,
      }
    });

    const reply = response.text;

    return NextResponse.json({ reply });
  } catch (error: any) {
    console.error('Chat API Error:', error);
    return NextResponse.json(
      { error: error.message || 'Terjadi kesalahan saat memproses percakapan' },
      { status: 500 }
    );
  }
}
